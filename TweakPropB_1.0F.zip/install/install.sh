#!/sbin/sh
#	
#	uniFlashScript
#
#	CodRLabworks
#	CodRCA : Christian Arvin
#	


##############################################################
# INIT
##############################################################
#
install_init(){
	# ! DO NOT REMOVE THE RETURN CODE !
	return 0
}

###############################################################
# MAIN
###############################################################
#
install_main() {
	# ! DO NOT REMOVE THE RETURN CODE !
	return 0
}

###############################################################
# POST SCRIPTS
###############################################################
# WARNING DO NOT UNMOUNT SYSTEM
install_post() {
	# ! DO NOT REMOVE THE RETURN CODE !
	return 0
}
